function output = hatice(x)

 %R1 x(3)
 %R2 x(2)
 %V1 x(1) 

hedef = (((7/(x(3)+x(2)+4)) - (((4+x(1))+(14/(x(3)+x(2)+4)))*(1/9)))^2)*-2; 
output = [hedef];   